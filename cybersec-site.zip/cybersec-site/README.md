# CyberSec

Full stack website for **CyberSec**, a cybersecurity firm offering security applications and training courses.

- **Frontend:** static HTML, CSS and JavaScript (`public/index.html`)
- **Backend:** Node.js and Express REST API
- **Database:** SQLite (file based, no separate server)
- **Auth:** email and password accounts with JWT tokens

## Features

- Live password-strength checker on the home page (runs in the browser only)
- Sign up and sign in, with passwords hashed using bcrypt
- Courses loaded from the API, with enroll buttons for signed-in users
- Contact form that saves messages to the database
- Admin-only endpoint to read contact messages
- Security basics: Helmet headers, rate limiting, input validation, parameterized SQL

## Project structure

```
cybersec-site/
├── server.js          Express app and security middleware
├── src/
│   ├── db.js          SQLite setup and seed courses
│   ├── middleware.js  JWT signing and auth checks
│   └── routes.js      API routes
├── public/
│   └── index.html     Frontend
├── package.json
├── .env.example       Template for your secrets and tokens
└── .gitignore
```

## Setup

Requires Node.js 18.11 or newer.

```bash
npm install
cp .env.example .env
```

Generate a JWT secret and paste it into `.env` as `JWT_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Set `ADMIN_EMAIL` in `.env` to your email. The account you register with that email becomes the admin.

Start the server:

```bash
npm start        # production
npm run dev      # restarts on file changes
```

Open http://localhost:3000.

## Tokens and secrets

| Variable | Purpose |
| --- | --- |
| `JWT_SECRET` | Signs login tokens. Required, 32+ characters. Keep it private. |
| `JWT_EXPIRES_IN` | Token lifetime, for example `7d` |
| `ADMIN_EMAIL` | Email that gets the admin role on registration |
| `PORT` | Server port, default 3000 |
| `DB_FILE` | Optional SQLite file path |
| `TRUST_PROXY` | Set to `1` when deployed behind a proxy |

Never commit `.env`. It is already in `.gitignore`. If a secret is ever pushed by mistake, generate a new one and redeploy.

The browser keeps the login token in `localStorage` and sends it as `Authorization: Bearer <token>`.

## API

| Method | Endpoint | Auth | Description |
| --- | --- | --- | --- |
| POST | `/api/auth/register` | No | Create account (`name`, `email`, `password`) |
| POST | `/api/auth/login` | No | Sign in (`email`, `password`) |
| GET | `/api/auth/me` | Yes | Current user |
| GET | `/api/courses` | No | List courses |
| POST | `/api/courses/:id/enroll` | Yes | Enroll in a course |
| GET | `/api/enrollments` | Yes | Your enrolled courses |
| POST | `/api/contact` | No | Send a message (`name`, `email`, `topic`, `message`) |
| GET | `/api/contact` | Admin | Read contact messages |

## Deploy

GitHub Pages only hosts static files, so it cannot run this backend. Deploy the repository to a Node host such as Render, Railway or Fly.io:

1. Connect the GitHub repo to the host.
2. Build command: `npm install`. Start command: `npm start`.
3. Add the variables from the table above in the host's environment settings, including `TRUST_PROXY=1`.
4. SQLite stores data in a file, so attach a persistent disk and point `DB_FILE` at it.

## Roadmap

- Payments for courses
- Course lesson content and progress tracking
- Admin dashboard
- Password reset by email

## License

MIT
