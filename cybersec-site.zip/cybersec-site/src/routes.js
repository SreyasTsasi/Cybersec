const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const db = require('./db');
const { sign, requireAuth, requireAdmin } = require('./middleware');

const r = express.Router();
const strict = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  message: { error: 'Too many attempts. Try again later.' }
});
const str = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const emailOk = (e) => e.length > 3 && e.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });

r.post('/auth/register', strict, (req, res) => {
  const name = str(req.body.name, 80);
  const email = str(req.body.email, 254).toLowerCase();
  const pw = req.body.password;
  if (!name || !emailOk(email) || typeof pw !== 'string' || pw.length < 10 || pw.length > 200) {
    return res.status(400).json({ error: 'Enter your name, a valid email and a password of at least 10 characters.' });
  }
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) {
    return res.status(409).json({ error: 'That email is already registered. Sign in instead.' });
  }
  const admin = (process.env.ADMIN_EMAIL || '').toLowerCase() === email;
  const info = db
    .prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)')
    .run(name, email, bcrypt.hashSync(pw, 12), admin ? 'admin' : 'student');
  const user = { id: Number(info.lastInsertRowid), name, email, role: admin ? 'admin' : 'student' };
  res.status(201).json({ token: sign(user), user });
});

r.post('/auth/login', strict, (req, res) => {
  const email = str(req.body.email, 254).toLowerCase();
  const pw = req.body.password;
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!row || typeof pw !== 'string' || !bcrypt.compareSync(pw, row.password_hash)) {
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  res.json({ token: sign(row), user: publicUser(row) });
});

r.get('/auth/me', requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.sub);
  if (!row) return res.status(401).json({ error: 'Account not found' });
  res.json({ user: publicUser(row) });
});

r.get('/courses', (req, res) => {
  res.json({ courses: db.prepare('SELECT id, slug, title, level, summary FROM courses ORDER BY id').all() });
});

r.post('/courses/:id/enroll', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare('SELECT 1 FROM courses WHERE id = ?').get(id)) {
    return res.status(404).json({ error: 'Course not found' });
  }
  db.prepare('INSERT OR IGNORE INTO enrollments (user_id, course_id) VALUES (?, ?)').run(req.user.sub, id);
  res.status(201).json({ ok: true });
});

r.get('/enrollments', requireAuth, (req, res) => {
  const rows = db
    .prepare('SELECT c.id, c.title FROM enrollments e JOIN courses c ON c.id = e.course_id WHERE e.user_id = ?')
    .all(req.user.sub);
  res.json({ enrollments: rows });
});

r.post('/contact', strict, (req, res) => {
  const name = str(req.body.name, 80);
  const email = str(req.body.email, 254).toLowerCase();
  const topic = str(req.body.topic, 80);
  const message = str(req.body.message, 2000);
  if (!name || !emailOk(email) || !message) {
    return res.status(400).json({ error: 'Enter your name, a valid email and a message.' });
  }
  db.prepare('INSERT INTO messages (name, email, topic, body) VALUES (?, ?, ?, ?)').run(name, email, topic, message);
  res.status(201).json({ ok: true });
});

r.get('/contact', requireAuth, requireAdmin, (req, res) => {
  res.json({ messages: db.prepare('SELECT * FROM messages ORDER BY id DESC LIMIT 200').all() });
});

module.exports = r;
