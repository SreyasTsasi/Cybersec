const path = require('path');
const Database = require('better-sqlite3');

const db = new Database(process.env.DB_FILE || path.join(__dirname, '..', 'data.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS courses (
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  level TEXT NOT NULL,
  summary TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS enrollments (
  user_id INTEGER NOT NULL REFERENCES users(id),
  course_id INTEGER NOT NULL REFERENCES courses(id),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, course_id)
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  topic TEXT,
  body TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

if (db.prepare('SELECT COUNT(*) AS n FROM courses').get().n === 0) {
  const add = db.prepare('INSERT INTO courses (slug, title, level, summary) VALUES (?, ?, ?, ?)');
  add.run('security-basics', 'Security Basics', 'Beginner', 'How attacks happen, how to spot phishing, and the habits that prevent most incidents.');
  add.run('soc-analyst-foundations', 'SOC Analyst Foundations', 'Intermediate', 'Read logs, triage alerts and write incident reports like a security operations analyst.');
  add.run('web-application-security', 'Web Application Security', 'Advanced', 'Test and secure real applications against the OWASP Top 10 in guided labs.');
}

module.exports = db;
